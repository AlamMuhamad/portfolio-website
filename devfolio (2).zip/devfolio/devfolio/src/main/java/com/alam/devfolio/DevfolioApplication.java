package com.alam.devfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevfolioApplication.class, args);

		System.out.println(("----------Done --------------"));
	}

}
