package com.alam.devfolio.controller;

import com.alam.devfolio.entity.ContactMessage;
import com.alam.devfolio.services.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HomeController {

    @Autowired
    private ContactService contactService;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("pageTitle", "Home");
        return "index";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("pageTitle", "About");
        return "about";
    }

//    @GetMapping("/contact")
//    public String contactForm(Model model) {
//        model.addAttribute("pageTitle", "Contact");
//        model.addAttribute("contactMessage", new ContactMessage()); // For binding
//        return "contact";
//    }

//    @PostMapping("/contact")
//    public String submitContact(@ModelAttribute ContactMessage contactMessage, Model model) {
//        contactService.saveMessage(contactMessage);
//        model.addAttribute("successMessage", "Message sent successfully!");
//        model.addAttribute("contactMessage", new ContactMessage()); // Clear form
//        return "contact";
//    }

    @GetMapping("/projects")
    public String project(Model model) {
        model.addAttribute("pageTitle", "Projects");
        return "projects";
    }

    @GetMapping("/services")
    public String services(Model model) {
        model.addAttribute("pageTitle", "Services");
        return "services";
    }

    @GetMapping("/testimonial")
    public String testimonial(Model model) {
        model.addAttribute("pageTitle", "Testimonials");
        return "testimonial";
    }

    @GetMapping("/blog")
    public String blog(Model model) {
        model.addAttribute("pageTitle", "Blog");
        return "blog";
    }

    @GetMapping("/admin")
    public String adminPanel(Model model) {
        model.addAttribute("pageTitle", "Admin Panel");
        return "admin";
    }
}
