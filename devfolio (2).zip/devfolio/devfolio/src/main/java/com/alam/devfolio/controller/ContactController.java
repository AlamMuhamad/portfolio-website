//package com.alam.devfolio.controller;
//
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//@Controller
//public class ContactController {
//
//    @GetMapping("/contact")
//    public String showContactForm() {
//        return "contact";
//    }
//
//    @PostMapping("/contact")
//    public String submitContactForm(@RequestParam String name,
//                                    @RequestParam String email,
//                                    @RequestParam String message,
//                                    Model model) {
//
//        // Simulate saving or sending message
//        System.out.println("Received message from: " + name + ", " + email + " -> " + message);
//
//        model.addAttribute("successMessage", "Thank you " + name + "! Your message has been sent.");
//        return "contact";
//    }
//}
