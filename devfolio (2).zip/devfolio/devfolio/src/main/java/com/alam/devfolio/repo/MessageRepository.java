package com.alam.devfolio.repo;


import com.alam.devfolio.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Long> {
}
