//package com.alam.devfolio.controller;
//
//import com.alam.devfolio.entity.ContactMessage;
//import com.alam.devfolio.services.ContactService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.ui.Model;
//
//@Controller
//public class MainController {
//
//    @Autowired
//    private ContactService contactService;
//
//    @GetMapping("/contact")
//    public String showContactForm() {
//        return "contact";
//    }
//
//    @PostMapping("/contact")
//    public String submitContactForm(@ModelAttribute ContactMessage message, Model model) {
//        contactService.saveMessage(message);
//        model.addAttribute("success", "Your message was sent!");
//        return "contact";
//    }
//}
