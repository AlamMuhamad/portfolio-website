package com.alam.devfolio.services;

import com.alam.devfolio.entity.Message;
import com.alam.devfolio.repo.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageService {

    @Autowired
    private MessageRepository messageRepository;

    public void saveMessage(Message message) {
        messageRepository.save(message);
    }

    public List<Message> getAllMessages() {
        return messageRepository.findAll();
    }

    public void deleteMessageById(Long id) {
        messageRepository.deleteById(id);
    }
}
