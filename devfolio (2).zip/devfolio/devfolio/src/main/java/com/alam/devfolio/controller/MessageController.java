package com.alam.devfolio.controller;

import com.alam.devfolio.entity.ContactMessage;
import com.alam.devfolio.entity.Message;
import com.alam.devfolio.services.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class MessageController {



    @Autowired
    private MessageService messageService;

    // Show contact form
    @GetMapping("/contact")
    public String showForm() {
        return "contact"; // contact.html
    }

    // Handle form submission
    @PostMapping("/contact")
    public String handleForm(@RequestParam String name,
                             @RequestParam String email,
                             @RequestParam String message,
                             Model model) {

        Message msg = new Message();
        msg.setName(name);
        msg.setEmail(email);
        msg.setMessage(message);

        messageService.saveMessage(msg);

        model.addAttribute("successMessage", "Thank you for your message!");
        return "contact";
    }

    // Admin view messages
//    @GetMapping("/admin/messages")
//    public String viewMessages(Model model) {
//        model.addAttribute("messages", messageService.getAllMessages());
//        return "messages"; // messages.html
//    }
    @GetMapping("/messages")
    public String viewMessages(Model model) {
        List<Message> messages = messageService.getAllMessages();
        model.addAttribute("messages", messages);
        return "messages"; // Thymeleaf page
    }

    @PostMapping("/admin/delete/{id}")
    public String deleteMessage(@PathVariable Long id) {
        messageService.deleteMessageById(id);
        return "redirect:/admin/messages";
    }
}
