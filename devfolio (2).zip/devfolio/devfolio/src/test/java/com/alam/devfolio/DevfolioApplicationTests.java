package com.alam.devfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
